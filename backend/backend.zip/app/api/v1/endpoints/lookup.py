"""CRUD endpoints for all lookup/reference tables."""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.core.permissions import P
from app.crud import lookup as crud
from app.crud.lookup import DuplicateError
from app.dependencies import PermissionChecker, get_current_active_user, get_db
from app.models.user import User
from app.schemas import lookup as schemas
from app.services.zone_sync import (
    ZoneSyncError,
    ZoneSyncNotConfigured,
    sync_zones_from_otm,
)

router = APIRouter()


# Lookup uchun umumiy permissionlar (barcha reference jadvallar: tests, smenas,
# session_states, regions, zones, reasons, reason_types, blacklist, genders).
# Role endpointlari alohida — role:* permissionlari bilan.

# Ma'lumotnomalar — har bir bo'lim o'z permissioniga ega. Ilgari bularning
# hammasi bitta `lookup:*` da edi va bir bo'limga ruxsat berish qolganlarini
# ham ochib yuborardi.
_REGION_CREATE = PermissionChecker(P.REGION_CREATE.code)
_REGION_UPDATE = PermissionChecker(P.REGION_UPDATE.code)
_REGION_DELETE = PermissionChecker(P.REGION_DELETE.code)

_ZONE_CREATE = PermissionChecker(P.ZONE_CREATE.code)
_ZONE_UPDATE = PermissionChecker(P.ZONE_UPDATE.code)
_ZONE_DELETE = PermissionChecker(P.ZONE_DELETE.code)

_TEST_CREATE = PermissionChecker(P.TEST_CREATE.code)
_TEST_UPDATE = PermissionChecker(P.TEST_UPDATE.code)
_TEST_DELETE = PermissionChecker(P.TEST_DELETE.code)

_SMENA_CREATE = PermissionChecker(P.SMENA_CREATE.code)
_SMENA_UPDATE = PermissionChecker(P.SMENA_UPDATE.code)
_SMENA_DELETE = PermissionChecker(P.SMENA_DELETE.code)

_SESSION_STATE_CREATE = PermissionChecker(P.SESSION_STATE_CREATE.code)
_SESSION_STATE_UPDATE = PermissionChecker(P.SESSION_STATE_UPDATE.code)
_SESSION_STATE_DELETE = PermissionChecker(P.SESSION_STATE_DELETE.code)

_REASON_CREATE = PermissionChecker(P.REASON_CREATE.code)
_REASON_UPDATE = PermissionChecker(P.REASON_UPDATE.code)
_REASON_DELETE = PermissionChecker(P.REASON_DELETE.code)

_REASON_TYPE_CREATE = PermissionChecker(P.REASON_TYPE_CREATE.code)
_REASON_TYPE_UPDATE = PermissionChecker(P.REASON_TYPE_UPDATE.code)
_REASON_TYPE_DELETE = PermissionChecker(P.REASON_TYPE_DELETE.code)

_GENDER_CREATE = PermissionChecker(P.GENDER_CREATE.code)
_GENDER_UPDATE = PermissionChecker(P.GENDER_UPDATE.code)
_GENDER_DELETE = PermissionChecker(P.GENDER_DELETE.code)

_BLACKLIST_CREATE = PermissionChecker(P.BLACKLIST_CREATE.code)
_BLACKLIST_UPDATE = PermissionChecker(P.BLACKLIST_UPDATE.code)
_BLACKLIST_DELETE = PermissionChecker(P.BLACKLIST_DELETE.code)

# Rol RO'YXATI (faqat nom/kalit) bir nechta sahifada selektor sifatida kerak:
# foydalanuvchi kartochkasi, davomat botlari, huquqlarni boshqarish. Shu bois
# ular ham o'tadi — `PermissionChecker` argumentlari OR bilan tekshiriladi.
# Rol YARATISH/TAHRIRLASH esa avvalgidek faqat role:create/update bilan.
_ROLE_READ = PermissionChecker(
    P.ROLE_READ.code,
    P.USER_READ.code,
    P.DAVOMAT_BOT_READ.code,
    P.ROLE_UPDATE.code,
)
_ROLE_CREATE = PermissionChecker(P.ROLE_CREATE.code)
_ROLE_UPDATE = PermissionChecker(P.ROLE_UPDATE.code)
_ROLE_DELETE = PermissionChecker(P.ROLE_DELETE.code)


def _handle_duplicate(e: DuplicateError):
    """Convert DuplicateError to 409 Conflict HTTPException."""
    raise HTTPException(status_code=409, detail=e.message)


# ===================== TEST =====================


@router.get("/tests", response_model=list[schemas.TestResponse], tags=["tests"])
def list_tests(
    db: Session = Depends(get_db), _: User = Depends(get_current_active_user)
):
    return crud.get_tests(db)


@router.post(
    "/tests", response_model=schemas.TestResponse, status_code=201, tags=["tests"]
)
def create_test(
    body: schemas.TestCreate,
    db: Session = Depends(get_db),
    _: User = Depends(_TEST_CREATE),
):
    try:
        return crud.create_test(db, body.model_dump())
    except DuplicateError as e:
        _handle_duplicate(e)


@router.patch("/tests/{item_id}", response_model=schemas.TestResponse, tags=["tests"])
def update_test(
    item_id: int,
    body: schemas.TestUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(_TEST_UPDATE),
):
    try:
        obj = crud.update_test(db, item_id, body.model_dump(exclude_unset=True))
    except DuplicateError as e:
        _handle_duplicate(e)
    if not obj:
        raise HTTPException(404, "Topilmadi")
    return obj


@router.delete("/tests/{item_id}", status_code=204, tags=["tests"])
def delete_test(
    item_id: int, db: Session = Depends(get_db), _: User = Depends(_TEST_DELETE)
):
    try:
        if not crud.delete_test(db, item_id):
            raise HTTPException(404, "Topilmadi")
    except DuplicateError as e:
        _handle_duplicate(e)


# ===================== SMENA =====================


@router.get("/smenas", response_model=list[schemas.SmenaResponse], tags=["smenas"])
def list_smenas(
    db: Session = Depends(get_db), _: User = Depends(get_current_active_user)
):
    return crud.get_smenas(db)


@router.post(
    "/smenas", response_model=schemas.SmenaResponse, status_code=201, tags=["smenas"]
)
def create_smena(
    body: schemas.SmenaCreate,
    db: Session = Depends(get_db),
    _: User = Depends(_SMENA_CREATE),
):
    try:
        return crud.create_smena(db, body.model_dump())
    except DuplicateError as e:
        _handle_duplicate(e)


@router.patch(
    "/smenas/{item_id}", response_model=schemas.SmenaResponse, tags=["smenas"]
)
def update_smena(
    item_id: int,
    body: schemas.SmenaUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(_SMENA_UPDATE),
):
    try:
        obj = crud.update_smena(db, item_id, body.model_dump(exclude_unset=True))
    except DuplicateError as e:
        _handle_duplicate(e)
    if not obj:
        raise HTTPException(404, "Topilmadi")
    return obj


@router.delete("/smenas/{item_id}", status_code=204, tags=["smenas"])
def delete_smena(
    item_id: int, db: Session = Depends(get_db), _: User = Depends(_SMENA_DELETE)
):
    try:
        if not crud.delete_smena(db, item_id):
            raise HTTPException(404, "Topilmadi")
    except DuplicateError as e:
        _handle_duplicate(e)


# ===================== SESSION STATE =====================


@router.get(
    "/session-states",
    response_model=list[schemas.SessionStateResponse],
    tags=["session-states"],
)
def list_session_states(
    db: Session = Depends(get_db), _: User = Depends(get_current_active_user)
):
    return crud.get_session_states(db)


@router.post(
    "/session-states",
    response_model=schemas.SessionStateResponse,
    status_code=201,
    tags=["session-states"],
)
def create_session_state(
    body: schemas.SessionStateCreate,
    db: Session = Depends(get_db),
    _: User = Depends(_SESSION_STATE_CREATE),
):
    try:
        return crud.create_session_state(db, body.model_dump())
    except DuplicateError as e:
        _handle_duplicate(e)


@router.patch(
    "/session-states/{item_id}",
    response_model=schemas.SessionStateResponse,
    tags=["session-states"],
)
def update_session_state(
    item_id: int,
    body: schemas.SessionStateUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(_SESSION_STATE_UPDATE),
):
    try:
        obj = crud.update_session_state(
            db, item_id, body.model_dump(exclude_unset=True)
        )
    except DuplicateError as e:
        _handle_duplicate(e)
    if not obj:
        raise HTTPException(404, "Topilmadi")
    return obj


@router.delete("/session-states/{item_id}", status_code=204, tags=["session-states"])
def delete_session_state(
    item_id: int, db: Session = Depends(get_db), _: User = Depends(_SESSION_STATE_DELETE)
):
    try:
        if not crud.delete_session_state(db, item_id):
            raise HTTPException(404, "Topilmadi")
    except DuplicateError as e:
        _handle_duplicate(e)


# ===================== REGION =====================


@router.get("/regions", response_model=list[schemas.RegionResponse], tags=["regions"])
def list_regions(
    db: Session = Depends(get_db), _: User = Depends(get_current_active_user)
):
    return crud.get_regions(db)


@router.post(
    "/regions", response_model=schemas.RegionResponse, status_code=201, tags=["regions"]
)
def create_region(
    body: schemas.RegionCreate,
    db: Session = Depends(get_db),
    _: User = Depends(_REGION_CREATE),
):
    try:
        return crud.create_region(db, body.model_dump())
    except DuplicateError as e:
        _handle_duplicate(e)


@router.patch(
    "/regions/{item_id}", response_model=schemas.RegionResponse, tags=["regions"]
)
def update_region(
    item_id: int,
    body: schemas.RegionUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(_REGION_UPDATE),
):
    try:
        obj = crud.update_region(db, item_id, body.model_dump(exclude_unset=True))
    except DuplicateError as e:
        _handle_duplicate(e)
    if not obj:
        raise HTTPException(404, "Topilmadi")
    return obj


@router.delete("/regions/{item_id}", status_code=204, tags=["regions"])
def delete_region(
    item_id: int, db: Session = Depends(get_db), _: User = Depends(_REGION_DELETE)
):
    try:
        if not crud.delete_region(db, item_id):
            raise HTTPException(404, "Topilmadi")
    except DuplicateError as e:
        _handle_duplicate(e)


# ===================== ZONE =====================


@router.get("/zones", response_model=list[schemas.ZoneResponse], tags=["zones"])
def list_zones(
    region_id: int | None = Query(None),
    db: Session = Depends(get_db),
    _: User = Depends(get_current_active_user),
):
    return crud.get_zones(db, region_id=region_id)


@router.get(
    "/zones/my-region",
    response_model=list[schemas.ZoneResponse],
    tags=["zones"],
    summary="Joriy foydalanuvchi region'idagi binolar",
)
def list_my_region_zones(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Foydalanuvchining o'z region'iga tegishli binolar (zonalar) ro'yxati.

    Desktop sync page buni chaqirib, user qaysi binoga ma'lumot yuklashini
    tanlaydi. Region JWT'dan aniqlanadi — client tomondan parameter kerak emas.
    """
    region_id = current_user.region_id
    if not region_id:
        raise HTTPException(
            status_code=400,
            detail=(
                "Foydalanuvchi hech qaysi zonaga biriktirilmagan — "
                "administrator bilan bog'laning"
            ),
        )
    return crud.get_zones(db, only_active=True, region_id=int(region_id))


@router.post(
    "/zones/sync-from-otm",
    response_model=schemas.ZoneSyncResult,
    tags=["zones"],
    summary="OTM tashqi API'dan binolarni sinxronizatsiya qilish",
)
def sync_zones_from_otm_endpoint(
    db: Session = Depends(get_db),
    _: User = Depends(_ZONE_CREATE),
):
    """Tashqi `API_OTM_ZONES` dan binolar ro'yxatini olib, tizimda mavjud
    bo'lmaganini insert qiladi.

    Moslik: `region_number` -> `Region.number`, `status` -> `Zone.is_active`.
    Mavjudlik kaliti: region ichida `name` + `number`. Mavjud bo'lsa o'tkazib
    yuboriladi, yo'q bo'lsa qo'shiladi. Hozircha tashqi API ishlamasligi mumkin —
    u holda 503/502 tushunarli xato qaytadi.
    """
    try:
        return sync_zones_from_otm(db)
    except ZoneSyncNotConfigured as e:
        raise HTTPException(
            status_code=503,
            detail=f"OTM zonalar API sozlanmagan: {e}",
        )
    except ZoneSyncError as e:
        raise HTTPException(status_code=502, detail=e.message)


@router.post(
    "/zones", response_model=schemas.ZoneResponse, status_code=201, tags=["zones"]
)
def create_zone(
    body: schemas.ZoneCreate,
    db: Session = Depends(get_db),
    _: User = Depends(_ZONE_CREATE),
):
    try:
        return crud.create_zone(db, body.model_dump())
    except DuplicateError as e:
        _handle_duplicate(e)


@router.patch("/zones/{item_id}", response_model=schemas.ZoneResponse, tags=["zones"])
def update_zone(
    item_id: int,
    body: schemas.ZoneUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(_ZONE_UPDATE),
):
    try:
        obj = crud.update_zone(db, item_id, body.model_dump(exclude_unset=True))
    except DuplicateError as e:
        _handle_duplicate(e)
    if not obj:
        raise HTTPException(404, "Topilmadi")
    return obj


@router.delete("/zones/{item_id}", status_code=204, tags=["zones"])
def delete_zone(
    item_id: int, db: Session = Depends(get_db), _: User = Depends(_ZONE_DELETE)
):
    try:
        if not crud.delete_zone(db, item_id):
            raise HTTPException(404, "Topilmadi")
    except DuplicateError as e:
        _handle_duplicate(e)


# ===================== ROLE =====================


@router.get("/roles", response_model=list[schemas.RoleResponse], tags=["roles"])
def list_roles(db: Session = Depends(get_db), _: User = Depends(_ROLE_READ)):
    return crud.get_roles(db)


@router.post(
    "/roles", response_model=schemas.RoleResponse, status_code=201, tags=["roles"]
)
def create_role(
    body: schemas.RoleCreate,
    db: Session = Depends(get_db),
    _: User = Depends(_ROLE_CREATE),
):
    try:
        return crud.create_role(db, body.model_dump())
    except DuplicateError as e:
        _handle_duplicate(e)


@router.patch("/roles/{item_id}", response_model=schemas.RoleResponse, tags=["roles"])
def update_role(
    item_id: int,
    body: schemas.RoleUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(_ROLE_UPDATE),
):
    try:
        obj = crud.update_role(db, item_id, body.model_dump(exclude_unset=True))
    except DuplicateError as e:
        _handle_duplicate(e)
    if not obj:
        raise HTTPException(404, "Topilmadi")
    return obj


@router.delete("/roles/{item_id}", status_code=204, tags=["roles"])
def delete_role(
    item_id: int, db: Session = Depends(get_db), _: User = Depends(_ROLE_DELETE)
):
    try:
        if not crud.delete_role(db, item_id):
            raise HTTPException(404, "Topilmadi")
    except DuplicateError as e:
        _handle_duplicate(e)


# ===================== REASON =====================


@router.get("/reasons", response_model=list[schemas.ReasonResponse], tags=["reasons"])
def list_reasons(
    db: Session = Depends(get_db), _: User = Depends(get_current_active_user)
):
    return crud.get_reasons(db)


@router.post(
    "/reasons", response_model=schemas.ReasonResponse, status_code=201, tags=["reasons"]
)
def create_reason(
    body: schemas.ReasonCreate,
    db: Session = Depends(get_db),
    _: User = Depends(_REASON_CREATE),
):
    try:
        return crud.create_reason(db, body.model_dump())
    except DuplicateError as e:
        _handle_duplicate(e)


@router.patch(
    "/reasons/{item_id}", response_model=schemas.ReasonResponse, tags=["reasons"]
)
def update_reason(
    item_id: int,
    body: schemas.ReasonUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(_REASON_UPDATE),
):
    try:
        obj = crud.update_reason(db, item_id, body.model_dump(exclude_unset=True))
    except DuplicateError as e:
        _handle_duplicate(e)
    if not obj:
        raise HTTPException(404, "Topilmadi")
    return obj


@router.delete("/reasons/{item_id}", status_code=204, tags=["reasons"])
def delete_reason(
    item_id: int, db: Session = Depends(get_db), _: User = Depends(_REASON_DELETE)
):
    try:
        if not crud.delete_reason(db, item_id):
            raise HTTPException(404, "Topilmadi")
    except DuplicateError as e:
        _handle_duplicate(e)


# ===================== REASON TYPE =====================


@router.get(
    "/reason-types",
    response_model=list[schemas.ReasonTypeResponse],
    tags=["reason-types"],
)
def list_reason_types(
    db: Session = Depends(get_db), _: User = Depends(get_current_active_user)
):
    return crud.get_reason_types(db)


@router.post(
    "/reason-types",
    response_model=schemas.ReasonTypeResponse,
    status_code=201,
    tags=["reason-types"],
)
def create_reason_type(
    body: schemas.ReasonTypeCreate,
    db: Session = Depends(get_db),
    _: User = Depends(_REASON_TYPE_CREATE),
):
    try:
        return crud.create_reason_type(db, body.model_dump())
    except DuplicateError as e:
        _handle_duplicate(e)


@router.patch(
    "/reason-types/{item_id}",
    response_model=schemas.ReasonTypeResponse,
    tags=["reason-types"],
)
def update_reason_type(
    item_id: int,
    body: schemas.ReasonTypeUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(_REASON_TYPE_UPDATE),
):
    try:
        obj = crud.update_reason_type(db, item_id, body.model_dump(exclude_unset=True))
    except DuplicateError as e:
        _handle_duplicate(e)
    if not obj:
        raise HTTPException(404, "Topilmadi")
    return obj


@router.delete("/reason-types/{item_id}", status_code=204, tags=["reason-types"])
def delete_reason_type(
    item_id: int, db: Session = Depends(get_db), _: User = Depends(_REASON_TYPE_DELETE)
):
    try:
        if not crud.delete_reason_type(db, item_id):
            raise HTTPException(404, "Topilmadi")
    except DuplicateError as e:
        _handle_duplicate(e)


# ===================== STUDENT BLACKLIST =====================


@router.get(
    "/blacklist",
    response_model=list[schemas.StudentBlacklistResponse],
    tags=["blacklist"],
)
def list_blacklist(
    db: Session = Depends(get_db), _: User = Depends(get_current_active_user)
):
    return crud.get_blacklist(db)


@router.post(
    "/blacklist",
    response_model=schemas.StudentBlacklistResponse,
    status_code=201,
    tags=["blacklist"],
)
def create_blacklist(
    body: schemas.StudentBlacklistCreate,
    db: Session = Depends(get_db),
    _: User = Depends(_BLACKLIST_CREATE),
):
    try:
        return crud.create_blacklist_item(db, body.model_dump())
    except DuplicateError as e:
        _handle_duplicate(e)


@router.patch(
    "/blacklist/{item_id}",
    response_model=schemas.StudentBlacklistResponse,
    tags=["blacklist"],
)
def update_blacklist(
    item_id: int,
    body: schemas.StudentBlacklistUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(_BLACKLIST_UPDATE),
):
    try:
        obj = crud.update_blacklist_item(
            db, item_id, body.model_dump(exclude_unset=True)
        )
    except DuplicateError as e:
        _handle_duplicate(e)
    if not obj:
        raise HTTPException(404, "Topilmadi")
    return obj


@router.delete("/blacklist/{item_id}", status_code=204, tags=["blacklist"])
def delete_blacklist(
    item_id: int, db: Session = Depends(get_db), _: User = Depends(_BLACKLIST_DELETE)
):
    try:
        if not crud.delete_blacklist_item(db, item_id):
            raise HTTPException(404, "Topilmadi")
    except DuplicateError as e:
        _handle_duplicate(e)


# ===================== GENDER =====================


@router.get("/genders", response_model=list[schemas.GenderResponse], tags=["genders"])
def list_genders(
    db: Session = Depends(get_db), _: User = Depends(get_current_active_user)
):
    return crud.get_genders(db)


@router.post(
    "/genders", response_model=schemas.GenderResponse, status_code=201, tags=["genders"]
)
def create_gender(
    body: schemas.GenderCreate,
    db: Session = Depends(get_db),
    _: User = Depends(_GENDER_CREATE),
):
    try:
        return crud.create_gender(db, body.model_dump())
    except DuplicateError as e:
        _handle_duplicate(e)


@router.patch(
    "/genders/{item_id}", response_model=schemas.GenderResponse, tags=["genders"]
)
def update_gender(
    item_id: int,
    body: schemas.GenderUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(_GENDER_UPDATE),
):
    try:
        obj = crud.update_gender(db, item_id, body.model_dump(exclude_unset=True))
    except DuplicateError as e:
        _handle_duplicate(e)
    if not obj:
        raise HTTPException(404, "Topilmadi")
    return obj


@router.delete("/genders/{item_id}", status_code=204, tags=["genders"])
def delete_gender(
    item_id: int, db: Session = Depends(get_db), _: User = Depends(_GENDER_DELETE)
):
    try:
        if not crud.delete_gender(db, item_id):
            raise HTTPException(404, "Topilmadi")
    except DuplicateError as e:
        _handle_duplicate(e)
