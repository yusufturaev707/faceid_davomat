from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

_INSECURE_SECRETS: set[str] = {
    "change-me-in-production-use-openssl-rand-hex-32",
    "CHANGE_ME__generate_with_secrets.token_urlsafe_48",
    "changeme",
    "secret",
}


class Settings(BaseSettings):
    # === Pydantic config — MUHIM, comment qilinmasin! ===
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,  # JWT_ISSUER == jwt_issuer
        extra="ignore",  # Noma'lum fieldlarni e'tiborsiz qoldirish
    )

    # Ilova nomi
    APP_NAME: str
    API_V1_PREFIX: str

    # JWT sozlamalari
    SECRET_KEY: str
    ALGORITHM: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int
    ADMIN_ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    JWT_ISSUER: str = "faceid-api"

    # API key hashlash uchun server-side pepper (SECRET_KEY'dan alohida).
    # Majburiy — bo'sh qoldirmang. Rotatsiya uchun: eski kalitlarni bekor qilib qayta yaratish.
    API_KEY_PEPPER: str

    # Refresh token
    REFRESH_TOKEN_EXPIRE_DAYS: int

    # Login lockout
    LOGIN_LOCKOUT_MAX_ATTEMPTS: int = 5
    LOGIN_LOCKOUT_WINDOW_SECONDS: int = 900
    LOGIN_LOCKOUT_DURATION_SECONDS: int = 900

    # CSRF
    CSRF_PROTECTION_ENABLED: bool = True

    # /metrics himoyasi
    METRICS_AUTH_TOKEN: str = ""

    # Cookie
    COOKIE_DOMAIN: str = ""

    # Database
    DATABASE_URL: str

    # DB connection pool va timeoutlar.
    # Idle ulanishlar firewall/NAT tomonidan jimgina uzilganda ("half-open"
    # socket) — keepalives ularni tirik tutadi va o'lganini tez aniqlaydi,
    # statement_timeout esa hech bir so'rov cheksiz "pending" qolmasligini
    # kafolatlaydi. Hammasi default qiymatli — .env ga qo'shish shart emas.
    DB_POOL_SIZE: int = 10
    DB_MAX_OVERFLOW: int = 20
    DB_POOL_TIMEOUT: int = 30
    # NAT/firewall idle timeout odatda ≥5 daqiqa — undan past qiymat
    # ulanishni eskirishidan oldin yangilaydi.
    DB_POOL_RECYCLE: int = 280
    # Yangi ulanish o'rnatish uchun cap (sekund).
    DB_CONNECT_TIMEOUT: int = 10
    # Server tomonida har bir SQL statement uchun qattiq limit (millisekund).
    # Ulanishdan KEYIN `SET statement_timeout` orqali beriladi (startup
    # parametri sifatida emas) — shuning uchun PgBouncer ham rad etmaydi.
    # 0 = o'chirilgan. Celery batch tasklari (student loader DELETE/INSERT)
    # ham shu engine'dan foydalanadi — qiymat ular uchun yetarli katta.
    # PgBouncer transaction-pooling rejimida eng ishonchli yo'l — buni
    # Postgres rolida sozlash: ALTER ROLE <user> SET statement_timeout='60s';
    DB_STATEMENT_TIMEOUT_MS: int = 60000

    # Rasm tekshiruv parametrlari
    MAX_BASE64_SIZE: int
    MIN_WIDTH: int
    MAX_WIDTH: int
    MIN_HEIGHT: int
    MAX_HEIGHT: int
    MIN_PALITRA_VALUE: int
    AGE_TOLERANCE: int
    SIMILARITY_THRESHOLD: float
    BG_COLOR_THRESHOLD: int

    # Rasm saqlash
    UPLOADS_PHOTO_DIR: str
    UPLOADS_FACE_DIR: str
    THUMBNAIL_SIZE: int
    WEBP_QUALITY: int

    # Tashqi natija tizimidagi rasm bazasi URL'i. Natija tahlilida `img` ustuni
    # qiymati shu bazaga qo'shilib to'liq rasm URL'i hosil qilinadi.
    BASE_IMG_URL: str = ""

    # ML Inference
    MAX_CONCURRENT_INFERENCE: int
    INFERENCE_TIMEOUT_SECONDS: float
    FACE_DET_SIZE: int = 320
    FACE_DET_THRESH: float = 0.3
    # ONNX intra-op thread soni (har bir inference nechta yadro ishlatadi).
    # 1 = har inference 1 yadro → ko'p rasmni PARALLEL qayta ishlashda (embedding)
    # yadrolarni to'la ishlatish mumkin. 0 = ONNX default (barcha yadro — bitta
    # inference ko'p yadroga yoyiladi, parallel throughput uchun yomon).
    FACE_ONNX_INTRA_THREADS: int = 1
    # Embedding chiqarishda parallel inference (thread pool) ishchilar soni.
    # 24 yadroli serverda ~16-20 optimal (qolgani OS/DB/decode uchun). Imtihon
    # paytida pasaytirish mumkin. 1 = ketma-ket (parallellik o'chirilgan).
    EMBEDDING_WORKERS: int = 16

    # Celery / Redis
    REDIS_URL: str
    TASK_RESULT_TTL: int

    # Backpressure
    QUEUE_MAX_SIZE: int = 100
    BACKPRESSURE_RETRY_AFTER: int = 5

    # Celery tuning
    TASK_TIME_LIMIT: int = 30
    WORKER_MAX_TASKS_PER_CHILD: int = 500
    # Redis broker visibility_timeout (sekund). Eng uzoq task (student loader
    # time_limit) dan KATTA bo'lishi shart — aks holda uzoq task qayta yuborilib,
    # bir sessiya uchun bir nechta loader parallel ishlaydi. Default 9 soat.
    BROKER_VISIBILITY_TIMEOUT: int = 32400
    # Student loader (700k+) uchun task time_limit (sekund). Default 8 soat.
    STUDENT_LOAD_TIME_LIMIT: int = 28800

    # Image decoder
    MAX_IMAGE_DIMENSION: int = 4096

    # Cookie
    COOKIE_SECURE: bool = True

    # CORS — Production'da .env orqali aniq domain ro'yxati berilishi shart.
    # Default faqat localhost dev uchun.
    # CORS_ORIGINS: list[str] = []
    CORS_ORIGINS: str = ""

    @property
    def cors_origins_list(self) -> list[str]:
        """CORS origins ro'yxat ko'rinishida."""
        if not self.CORS_ORIGINS:
            return []
        return [
            origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()
        ]

    # Tashqi API
    API_CEFR: str = ""
    API_MS: str = ""
    API_IIV: str = ""
    API_IIV_TOKEN: str = ""
    API_GTSP: str = ""
    # OTM binolari (zonalari) ro'yxati keladigan tashqi API. Admin "Yangilash"
    # tugmasi orqali chaqiriladi — javob {id, region_number, name, number,
    # order, status} strukturasidagi ro'yxat. Bo'sh bo'lsa endpoint 503 qaytaradi.
    API_OTM_ZONES: str = ""
    API_OTM_ZONES_TOKEN: str = ""
    # OTM-DTM talabgorlari keladigan tashqi API (Test.key='otm-dtm'). CEFR
    # kabi sahifalangan (paginated) javob kutiladi — URL'da {0}=sana, {1}=sahifa.
    API_OTM_STUDENTS: str = ""
    API_OTM_STUDENTS_TOKEN: str = ""

    # Proctoring tizimi — kompyuterlarni biriktirish va nomzodni bron qilish
    # (`services/proctoring_client.py`). URL — `.../api/v1` gacha, kalit
    # `X-API-Key` sarlavhasida ketadi. Bo'sh bo'lsa endpointlar 503 qaytaradi,
    # bron esa jimgina o'tkazib yuboriladi (davomat to'xtamasligi kerak).
    PROCTORING_API_URL: str = ""
    PROCTORING_API_KEY: str = ""
    PROCTORING_TIMEOUT: float = 10.0

    # E-GOV PSN — PINFL bo'yicha joriy pasport (seriya + raqam) olish.
    # `API_GET_TOKEN_EGOV` ga POST -> Bearer access_token (~1 soat amal qiladi),
    # so'ng shu token bilan `API_PSN_EGOV` ga POST. Ikkalasi ham bo'sh bo'lsa
    # "PSN" orqali passport yangilash endpointi 503 qaytaradi.
    API_GET_TOKEN_EGOV: str = ""
    API_PSN_EGOV: str = ""
    # Token endpointi klient autentifikatsiyasini talab qiladi — qiymat
    # `Authorization` headeriga o'zgartirishsiz qo'yiladi (e-gov bergan holicha).
    # Bo'sh bo'lsa endpoint 401 `invalid_client` qaytaradi.
    API_AUTH_TOKEN_EGOV: str = ""

    # Statistika bot — tashqi statistika API (qabul ko'rsatkichlari).
    # Bot endi to'g'ridan-to'g'ri emas, shu backend orqali oladi.
    API_STATISTIC_BOT: str = "https://api.uzbmb.uz/site/telegram-bot-statistics"
    API_STATISTIC_BOT_TOKEN: str = ""
    # Tashqi API javobini necha soniya kesh saqlash (so'rovlarni kamaytirish).
    STATISTIC_BOT_CACHE_TTL: int = 60
    # Qabul joriy yili. 0 = avtomatik (tashqi API kalitlaridan aniqlanadi).
    # Faqat ma'lumot bo'sh bo'lganda fallback sifatida ishlatiladi.
    QABUL_YEAR: int = 0

    # Davomat Telegram Mini App (`/api/v1/davomat-miniapp`).
    # Bot tokeni (davomat_bot/.env dagi BOT_TOKEN bilan bir xil) — Mini App
    # `initData` imzosini (HMAC) tekshirish va kelmaganlar Excel faylini
    # foydalanuvchi chatiga yuborish uchun. Bo'sh bo'lsa Mini App 503 qaytaradi.
    DAVOMAT_BOT_TOKEN: str = ""
    # Chetlatish yozuvlari (`cheating_logs.user_id`) shu foydalanuvchi nomidan
    # yoziladi — bot kanalidagi kabi bot API kalitining egasi (`users.id`).
    # 0 bo'lsa Mini App 503 qaytaradi.
    DAVOMAT_MINIAPP_USER_ID: int = 0
    # initData amal qilish muddati (sekund). Telegram initData'ni Mini App
    # ochilganda bir marta beradi — operator ilovani kun bo'yi ochiq tutadi.
    DAVOMAT_MINIAPP_INIT_DATA_TTL: int = 86400
    # Face ID tasdig'i shu muddat ichida "Davomatga qo'shish" bilan
    # yakunlanishi kerak (sekund).
    DAVOMAT_MINIAPP_VERIFY_TTL: int = 600
    # Telegram Bot API manzili (lokal Bot API server/proxy uchun almashtiriladi).
    TELEGRAM_API_BASE: str = "https://api.telegram.org"

    @field_validator("SECRET_KEY", "API_KEY_PEPPER")
    @classmethod
    def _reject_insecure_secrets(cls, v: str, info) -> str:
        if not v or v.strip() in _INSECURE_SECRETS or len(v) < 32:
            raise ValueError(
                f"{info.field_name} placeholder/zaif qiymatga ega. "
                'Yangi qiymat: python -c "import secrets; print(secrets.token_urlsafe(48))"'
            )
        return v


settings = Settings()
