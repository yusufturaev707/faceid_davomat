from logging.config import fileConfig

from alembic import context
from app.config import settings
from app.db.base import Base

# Barcha modellarni import qilish (Alembic autogenerate uchun)
from app.models import (  # noqa: F401
    ApiKey,
    CheatingLog,
    Permission,
    Reason,
    ReasonType,
    RefreshToken,
    Region,
    Role,
    SessionState,
    Smena,
    Student,
    StudentBlacklist,
    StudentLog,
    StudentPsData,
    Test,
    TestSession,
    TestSessionSmena,
    User,
    VerificationLog,
    VerifyFaces,
    Zone,
)
from sqlalchemy import engine_from_config, pool

config = context.config

# alembic.ini dan sqlalchemy.url ni override qilish
# config.set_main_option("sqlalchemy.url", settings.DATABASE_URL)
db_url = settings.DATABASE_URL.replace("%", "%%")
config.set_main_option("sqlalchemy.url", db_url)

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(url=url, target_metadata=target_metadata, literal_binds=True)
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
