"""user region_id column

Foydalanuvchini bevosita region'ga biriktirish. Avval region `zone → region`
orqali hosilaviy aniqlanardi; endi `users.region_id` real ustun va asosiy
(authoritative) bog'lanish. `zone_id` ixtiyoriy "uy zonasi" sifatida saqlanadi.

Revision ID: a7b8c9d0e1f2
Revises: e5f6a7b8c9d0
Create Date: 2026-05-20 12:00:00.000000
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'a7b8c9d0e1f2'
down_revision: Union[str, None] = 'e5f6a7b8c9d0'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        'users',
        sa.Column('region_id', sa.Integer(), nullable=True),
    )
    op.create_index('ix_users_region_id', 'users', ['region_id'])
    op.create_foreign_key(
        'fk_users_region_id_regions',
        'users', 'regions',
        ['region_id'], ['id'],
    )
    # Backfill — mavjud foydalanuvchilarning region'i biriktirilgan zonasidan
    # aniqlanadi, shunda eski akkauntlar migratsiyadan keyin darhol ishlaydi.
    op.execute(
        """
        UPDATE users
        SET region_id = zone.region_id
        FROM zone
        WHERE users.zone_id = zone.id
          AND users.region_id IS NULL
        """
    )


def downgrade() -> None:
    op.drop_constraint('fk_users_region_id_regions', 'users', type_='foreignkey')
    op.drop_index('ix_users_region_id', table_name='users')
    op.drop_column('users', 'region_id')
