"""Naive datetime ustunlarini TIMESTAMPTZ ga o'tkazish (8 ta jadval)

Hozirgacha quyidagi ustunlar TIMESTAMP WITHOUT TIME ZONE (naive) edi:
  - student_logs.first_enter_time, last_enter_time
  - davomat_bots.created_at, updated_at
  - student_blacklist.created_at
  - failed_login_attempts.attempted_at
  - verification_logs.timestamp
  - verify_faces.timestamp
  - users.created_at, updated_at
  - api_keys.created_at, last_used_at

Naive qiymatlar JSON'ga timezone suffixsiz serialize qilinardi va frontend
`new Date(s)` ularni local time deb talqin qilardi (Tashkent UTC+5 da
5 soat farq). Postgres container UTC'da ishlagani va `func.now()` /
`current_timestamp()` UTC yozgani uchun mavjud qiymatlar UTC deb
interpretatsiya qilinadi.

`refresh_tokens` (c3d4e5f6a7b8) va `cheating_logs` (f6a7b8c9d0e1)
allaqachon o'tkazilgan — bu migration qolgan jadvallarni bir vaqtda
yangilaydi.

Revision ID: a8b9c0d1e2f3
Revises: f6a7b8c9d0e1
Create Date: 2026-06-01 00:00:00.000000
"""
from typing import Sequence, Union

from alembic import op

# revision identifiers, used by Alembic.
revision: str = 'a8b9c0d1e2f3'
down_revision: Union[str, None] = 'f6a7b8c9d0e1'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# (table, column) juftliklari ro'yxati.
_TARGETS: tuple[tuple[str, str], ...] = (
    ("student_logs", "first_enter_time"),
    ("student_logs", "last_enter_time"),
    ("davomat_bots", "created_at"),
    ("davomat_bots", "updated_at"),
    ("student_blacklist", "created_at"),
    ("failed_login_attempts", "attempted_at"),
    ("verification_logs", "timestamp"),
    ("verify_faces", "timestamp"),
    ("users", "created_at"),
    ("users", "updated_at"),
    ("api_keys", "created_at"),
    ("api_keys", "last_used_at"),
)


def upgrade() -> None:
    # Raw ALTER COLUMN TYPE — Postgres NOT NULL va DEFAULT'larni saqlaydi.
    # USING ... AT TIME ZONE 'UTC': naive qiymat UTC deb o'qiladi.
    for table, col in _TARGETS:
        op.execute(
            f"ALTER TABLE {table} "
            f"ALTER COLUMN {col} TYPE TIMESTAMP WITH TIME ZONE "
            f"USING {col} AT TIME ZONE 'UTC'"
        )


def downgrade() -> None:
    for table, col in _TARGETS:
        op.execute(
            f"ALTER TABLE {table} "
            f"ALTER COLUMN {col} TYPE TIMESTAMP WITHOUT TIME ZONE "
            f"USING {col} AT TIME ZONE 'UTC'"
        )
