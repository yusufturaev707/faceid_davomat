"""add building_id to zone table

Revision ID: a9b0e7221b9f
Revises: e1f2a3b4c5d6
Create Date: 2026-07-01 11:19:37.052086
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "a9b0e7221b9f"
down_revision: Union[str, None] = "e1f2a3b4c5d6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # `zone.building_id` — tashqi OTM API'dagi bino "id" qiymati.
    # Nullable: mavjud/qo'lda yaratilgan zonalar hali biror binoga bog'lanmagan
    # bo'lishi mumkin (NULL bo'lib qoladi, sinxronizatsiya to'ldiradi).
    # Unikal indeks: bir tashqi bino bitta zonaga to'g'ri keladi. Postgres bir
    # nechta NULL qiymatga ruxsat beradi, shuning uchun bog'lanmagan zonalar
    # unikallikni buzmaydi.
    op.add_column("zone", sa.Column("building_id", sa.Integer(), nullable=True))
    op.create_index(
        op.f("ix_zone_building_id"), "zone", ["building_id"], unique=True
    )


def downgrade() -> None:
    op.drop_index(op.f("ix_zone_building_id"), table_name="zone")
    op.drop_column("zone", "building_id")
