"""statistic_bots jadvali

Statistika telegram bot foydalanuvchilari uchun ro'yxat. `telegram_id`
orqali bot dostupi tekshiriladi. `role` — butun son (1=Admin, 2=Rahbar,
3=Xodim); FK yo'q.

Revision ID: b1c2d3e4f5a6
Revises: a8b9c0d1e2f3
Create Date: 2026-06-09 10:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = 'b1c2d3e4f5a6'
down_revision: Union[str, None] = 'a8b9c0d1e2f3'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'statistic_bots',
        sa.Column('id', sa.Integer(), primary_key=True, index=True),
        sa.Column('fio', sa.String(length=150), nullable=False),
        sa.Column('role', sa.SmallInteger(), nullable=False, server_default='3'),
        sa.Column('telegram_id', sa.BigInteger(), nullable=False),
        sa.Column(
            'status', sa.Boolean(),
            nullable=False, server_default=sa.true(),
        ),
        sa.Column(
            'created_at', sa.TIMESTAMP(timezone=True),
            nullable=False, server_default=sa.func.current_timestamp(),
        ),
        sa.Column(
            'updated_at', sa.TIMESTAMP(timezone=True),
            nullable=False, server_default=sa.func.current_timestamp(),
        ),
        sa.UniqueConstraint('telegram_id', name='uq_statistic_bots_telegram_id'),
    )
    op.create_index(
        'ix_statistic_bots_telegram_id', 'statistic_bots', ['telegram_id'],
    )


def downgrade() -> None:
    op.drop_index('ix_statistic_bots_telegram_id', table_name='statistic_bots')
    op.drop_table('statistic_bots')
