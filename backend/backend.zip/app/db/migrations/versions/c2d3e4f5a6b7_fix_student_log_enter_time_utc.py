"""student_logs kirish vaqtlarini UTC'ga tuzatish (desktop yozuvlari)

Muammo: desktop client `first_enter_time`/`last_enter_time` ni naive lokal
(Toshkent, UTC+5) vaqt sifatida yuborgan va u `timestamptz` ustunga
konvertatsiyasiz yozilgan — natijada lokal vaqt xato ravishda "UTC" deb
saqlangan. Frontend uni yana +5 soat surib, 5 soat keyingi vaqtni ko'rsatgan.

Tuzatish: desktop yozuvlariga -5 soat qo'llaymiz, shunda ustunda haqiqiy
absolyut UTC vaqt qoladi.

Bot (`POST /bot/mark-attendance`) yozuvlari `datetime.now(timezone.utc)` bilan
allaqachon to'g'ri UTC saqlangan — ularga TEGMAYMIZ. Bot yozuvlarining imzosi:
`is_check_hand = TRUE AND max_score = 0` (bot scorega 0-100 foiz yozadi, ammo
max_score'ni atayin 0 qoldiradi). Eslatma: desktop'dagi qo'lda tasdiqlangan va
hali baholanmagan (is_check_hand=TRUE, max_score=0) kam sonli yozuvlar ham
shu filtrga tushib, tuzatilmay qoladi — bu xavfsiz tomon (noto'g'ri tuzatishdan
ko'ra tuzatmaslik afzal).

Revision ID: c2d3e4f5a6b7
Revises: b1c2d3e4f5a6
Create Date: 2026-06-09 12:00:00.000000
"""
from typing import Sequence, Union

from alembic import op

# revision identifiers, used by Alembic.
revision: str = 'c2d3e4f5a6b7'
down_revision: Union[str, None] = 'b1c2d3e4f5a6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# Bot yozuvlarini chetlab o'tuvchi shart — faqat desktop yozuvlari tuzatiladi.
_DESKTOP_ONLY = "NOT (is_check_hand = TRUE AND max_score = 0)"


def upgrade() -> None:
    op.execute(
        f"""
        UPDATE student_logs
        SET
            first_enter_time = first_enter_time - INTERVAL '5 hours',
            last_enter_time  = last_enter_time  - INTERVAL '5 hours'
        WHERE {_DESKTOP_ONLY}
        """
    )


def downgrade() -> None:
    op.execute(
        f"""
        UPDATE student_logs
        SET
            first_enter_time = first_enter_time + INTERVAL '5 hours',
            last_enter_time  = last_enter_time  + INTERVAL '5 hours'
        WHERE {_DESKTOP_ONLY}
        """
    )
