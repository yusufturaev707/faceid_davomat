"""region s_number and k_number columns

Region (viloyat) jadvaliga ikkita yangi raqamli identifikator: `s_number`
va `k_number`. Ikkalasi ham unikal va NOT NULL. Mavjud yozuvlar uchun ular
`number` qiymati bilan backfill qilinadi — shunda unikal cheklov buzilmaydi.

Revision ID: d1e2f3a4b5c6
Revises: c2d3e4f5a6b7
Create Date: 2026-06-22 12:00:00.000000
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'd1e2f3a4b5c6'
down_revision: Union[str, None] = 'c2d3e4f5a6b7'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # 1) Avval nullable qo'shamiz — mavjud qatorlar uchun NOT NULL'ni
    #    backfill'dan keyin o'rnatamiz.
    op.add_column('regions', sa.Column('s_number', sa.Integer(), nullable=True))
    op.add_column('regions', sa.Column('k_number', sa.Integer(), nullable=True))

    # 2) Backfill — har bir mavjud region uchun `number` qiymatini ishlatamiz.
    #    `number` unikal bo'lgani uchun yangi ustunlar ham unikal bo'ladi.
    op.execute("UPDATE regions SET s_number = number, k_number = number")

    # 3) NOT NULL + unikal cheklovlar (model bilan mos).
    op.alter_column('regions', 's_number', nullable=False)
    op.alter_column('regions', 'k_number', nullable=False)
    op.create_unique_constraint('uq_regions_s_number', 'regions', ['s_number'])
    op.create_unique_constraint('uq_regions_k_number', 'regions', ['k_number'])


def downgrade() -> None:
    op.drop_constraint('uq_regions_k_number', 'regions', type_='unique')
    op.drop_constraint('uq_regions_s_number', 'regions', type_='unique')
    op.drop_column('regions', 'k_number')
    op.drop_column('regions', 's_number')
