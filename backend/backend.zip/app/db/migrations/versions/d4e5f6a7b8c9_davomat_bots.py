"""davomat_bots va davomat_bot_regions jadvallari

Telegram bot foydalanuvchilari uchun ro'yxat. `telegram_id` orqali
bot dostupi tekshiriladi. Asosiy region/zone + qo'shimcha regionlar M2M.

Revision ID: d4e5f6a7b8c9
Revises: c3d4e5f6a7b8
Create Date: 2026-05-16 12:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = 'd4e5f6a7b8c9'
down_revision: Union[str, None] = 'c3d4e5f6a7b8'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'davomat_bots',
        sa.Column('id', sa.Integer(), primary_key=True, index=True),
        sa.Column('fio', sa.String(length=150), nullable=False),
        sa.Column('telegram_id', sa.BigInteger(), nullable=False),
        sa.Column(
            'region_id', sa.Integer(),
            sa.ForeignKey('regions.id', ondelete='SET NULL'),
            nullable=True,
        ),
        sa.Column(
            'zone_id', sa.Integer(),
            sa.ForeignKey('zone.id', ondelete='SET NULL'),
            nullable=True,
        ),
        sa.Column(
            'is_active', sa.Boolean(),
            nullable=False, server_default=sa.true(),
        ),
        sa.Column(
            'created_at', sa.DateTime(),
            nullable=False, server_default=sa.func.now(),
        ),
        sa.Column(
            'updated_at', sa.DateTime(),
            nullable=False, server_default=sa.func.now(),
        ),
        sa.UniqueConstraint('telegram_id', name='uq_davomat_bots_telegram_id'),
    )
    op.create_index(
        'ix_davomat_bots_telegram_id', 'davomat_bots', ['telegram_id'],
    )
    op.create_index(
        'ix_davomat_bots_region_id', 'davomat_bots', ['region_id'],
    )
    op.create_index(
        'ix_davomat_bots_zone_id', 'davomat_bots', ['zone_id'],
    )

    op.create_table(
        'davomat_bot_regions',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column(
            'davomat_bot_id', sa.Integer(),
            sa.ForeignKey('davomat_bots.id', ondelete='CASCADE'),
            nullable=False,
        ),
        sa.Column(
            'region_id', sa.Integer(),
            sa.ForeignKey('regions.id', ondelete='CASCADE'),
            nullable=False,
        ),
        sa.Column(
            'created_at', sa.DateTime(),
            nullable=False, server_default=sa.func.now(),
        ),
        sa.Column(
            'updated_at', sa.DateTime(),
            nullable=False, server_default=sa.func.now(),
        ),
        sa.UniqueConstraint(
            'davomat_bot_id', 'region_id', name='uq_davomat_bot_region',
        ),
    )
    op.create_index(
        'ix_davomat_bot_regions_bot', 'davomat_bot_regions',
        ['davomat_bot_id'],
    )
    op.create_index(
        'ix_davomat_bot_regions_region', 'davomat_bot_regions',
        ['region_id'],
    )


def downgrade() -> None:
    op.drop_index('ix_davomat_bot_regions_region', table_name='davomat_bot_regions')
    op.drop_index('ix_davomat_bot_regions_bot', table_name='davomat_bot_regions')
    op.drop_table('davomat_bot_regions')

    op.drop_index('ix_davomat_bots_zone_id', table_name='davomat_bots')
    op.drop_index('ix_davomat_bots_region_id', table_name='davomat_bots')
    op.drop_index('ix_davomat_bots_telegram_id', table_name='davomat_bots')
    op.drop_table('davomat_bots')
