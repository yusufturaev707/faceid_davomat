"""region.is_have_part and zone.is_part boolean columns

Region (viloyat) jadvaliga `is_have_part` — viloyat bo'limlarga (qismlarga)
bo'linganmi; Zone (bino) jadvaliga `is_part` — bino shunday bo'limga (qismga)
tegishlimi. Ikkalasi ham NOT NULL, default FALSE.

Boolean ustunlarda `server_default=FALSE` doimiy saqlanadi (b2c3d4e5f6a7 dagi
kabi) — ORM `default`ini chetlab o'tadigan INSERT'larda NOT NULL buzilmasligi
uchun. Mavjud qatorlar default orqali FALSE bo'ladi.

Revision ID: e1f2a3b4c5d6
Revises: d1e2f3a4b5c6
Create Date: 2026-06-24 12:00:00.000000
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'e1f2a3b4c5d6'
down_revision: Union[str, None] = 'd1e2f3a4b5c6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        'regions',
        sa.Column(
            'is_have_part',
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )
    op.add_column(
        'zone',
        sa.Column(
            'is_part',
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )


def downgrade() -> None:
    op.drop_column('zone', 'is_part')
    op.drop_column('regions', 'is_have_part')
