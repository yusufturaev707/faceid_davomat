"""student pc assignment (proctoring)

Revision ID: e2c77cfb2bf0
Revises: a9b0e7221b9f
Create Date: 2026-09-25 12:00:00.000000
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "e2c77cfb2bf0"
down_revision: Union[str, None] = "a9b0e7221b9f"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Yangi jadval yo'q — bitta ustun va bitta qisman indeks. Nullable
    # ustun qo'shish jadvalni qayta yozmaydi (700k qatorda ham bir lahza).
    # `proctoring_schedule_id IS NOT NULL` — "`sp_n` kompyuter raqami".
    op.add_column(
        "students",
        sa.Column("proctoring_schedule_id", sa.Integer(), nullable=True),
    )
    # CONCURRENTLY — imtihon kuni ham migratsiya `students` ga yozishni
    # to'smasin (desktop client'lar davomat yuborib turadi). U tranzaksiya
    # ichida ishlamaydi, shuning uchun `autocommit_block`. Indeks faqat
    # biriktirilgan qatorlarni qamraydi — hozir ular yo'q, ya'ni mavjud
    # takroriy `sp_n` (loader qiymatlari) unga xalaqit bermaydi.
    with op.get_context().autocommit_block():
        op.create_index(
            "uq_students_smena_zone_pc",
            "students",
            ["session_smena_id", "zone_id", "sp_n"],
            unique=True,
            postgresql_where=sa.text("proctoring_schedule_id IS NOT NULL"),
            postgresql_concurrently=True,
        )


def downgrade() -> None:
    with op.get_context().autocommit_block():
        op.drop_index(
            "uq_students_smena_zone_pc",
            table_name="students",
            postgresql_concurrently=True,
        )
    op.drop_column("students", "proctoring_schedule_id")
