"""davomat_bots: drop region_id/zone_id, add role_id

`davomat_bots` jadvalidagi asosiy `region_id` va `zone_id` ustunlari olib
tashlanadi — endi barcha regionlar `davomat_bot_regions` M2M jadvali orqali
biriktiriladi. Yangi `role_id` ustuni `roles` jadvaliga FK (nullable).

Ma'lumotlarni saqlash: upgrade davrida mavjud `region_id` qiymatlari
`davomat_bot_regions` ga ko'chiriladi (agar shu kombinatsiya yo'q bo'lsa).

Revision ID: e5f6a7b8c9d0
Revises: d4e5f6a7b8c9
Create Date: 2026-05-18 09:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


# revision identifiers, used by Alembic.
revision: str = "e5f6a7b8c9d0"
down_revision: Union[str, None] = "d4e5f6a7b8c9"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # 1) Mavjud `region_id` qiymatlarini M2M jadvalga ko'chirish — agar
    #    shu (davomat_bot_id, region_id) juftligi M2M da yo'q bo'lsa.
    op.execute(
        """
        INSERT INTO davomat_bot_regions (davomat_bot_id, region_id, created_at, updated_at)
        SELECT b.id, b.region_id, NOW(), NOW()
        FROM davomat_bots b
        WHERE b.region_id IS NOT NULL
          AND NOT EXISTS (
              SELECT 1 FROM davomat_bot_regions r
              WHERE r.davomat_bot_id = b.id AND r.region_id = b.region_id
          )
        """
    )

    # 2) Eski indekslar va FK ustunlarini olib tashlash.
    op.drop_index("ix_davomat_bots_region_id", table_name="davomat_bots")
    op.drop_index("ix_davomat_bots_zone_id", table_name="davomat_bots")

    with op.batch_alter_table("davomat_bots") as batch:
        batch.drop_column("region_id")
        batch.drop_column("zone_id")
        batch.add_column(
            sa.Column(
                "role_id",
                sa.Integer(),
                sa.ForeignKey("roles.id", ondelete="SET NULL"),
                nullable=True,
            )
        )

    op.create_index(
        "ix_davomat_bots_role_id", "davomat_bots", ["role_id"]
    )


def downgrade() -> None:
    op.drop_index("ix_davomat_bots_role_id", table_name="davomat_bots")
    with op.batch_alter_table("davomat_bots") as batch:
        batch.drop_column("role_id")
        batch.add_column(
            sa.Column(
                "region_id",
                sa.Integer(),
                sa.ForeignKey("regions.id", ondelete="SET NULL"),
                nullable=True,
            )
        )
        batch.add_column(
            sa.Column(
                "zone_id",
                sa.Integer(),
                sa.ForeignKey("zone.id", ondelete="SET NULL"),
                nullable=True,
            )
        )
    op.create_index(
        "ix_davomat_bots_region_id", "davomat_bots", ["region_id"]
    )
    op.create_index(
        "ix_davomat_bots_zone_id", "davomat_bots", ["zone_id"]
    )
