"""cheating_logs: created_at va updated_at ustunlarini timezone-aware qilish

Avval TIMESTAMP WITHOUT TIME ZONE edi — psycopg2 ularni naive datetime
qilib qaytarardi va frontend `new Date(s)`'da timezone suffix yo'qligi
sababli local time deb talqin qilar edi (Tashkent UTC+5 da 5 soat farq).

Mavjud qiymatlar UTC deb interpretatsiya qilinadi: Postgres container
default UTC'da ishlaydi va `server_default=func.current_timestamp()`
qiymatlari UTCda yozilgan.

Revision ID: f6a7b8c9d0e1
Revises: a7b8c9d0e1f2
Create Date: 2026-06-01 00:00:00.000000
"""
from typing import Sequence, Union

from alembic import op

# revision identifiers, used by Alembic.
revision: str = 'f6a7b8c9d0e1'
down_revision: Union[str, None] = 'a7b8c9d0e1f2'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_COLUMNS = ("created_at", "updated_at")


def upgrade() -> None:
    # Raw ALTER COLUMN TYPE — Postgres NOT NULL va DEFAULT'larni saqlaydi.
    # USING ... AT TIME ZONE 'UTC': naive qiymat UTC deb o'qiladi.
    for col in _COLUMNS:
        op.execute(
            f"ALTER TABLE cheating_logs "
            f"ALTER COLUMN {col} TYPE TIMESTAMP WITH TIME ZONE "
            f"USING {col} AT TIME ZONE 'UTC'"
        )


def downgrade() -> None:
    for col in _COLUMNS:
        op.execute(
            f"ALTER TABLE cheating_logs "
            f"ALTER COLUMN {col} TYPE TIMESTAMP WITHOUT TIME ZONE "
            f"USING {col} AT TIME ZONE 'UTC'"
        )
