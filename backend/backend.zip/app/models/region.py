from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class Region(Base):
    __tablename__ = "regions"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(100))
    number: Mapped[int] = mapped_column(unique=True)
    s_number: Mapped[int] = mapped_column(unique=True, default=0)
    k_number: Mapped[int] = mapped_column(unique=True, default=0)
    is_have_part: Mapped[bool] = mapped_column(default=False)
    is_active: Mapped[bool] = mapped_column(default=True)
